import java.math.RoundingMode;
import java.text.DecimalFormat;
/**
 * Write a description of class GPACalc here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GPACalc
{
    private static DecimalFormat df = new DecimalFormat("0.00");
    

    public static void Main()
    {
        ///regular grades
        double Ar = 4.0;
        double Br = 3.0;
        double Cr = 2.0;
        double Dr = 1.0;
        double Fr = 0.0;
        ///weighted grades
        double Aw = 5.0;
        double Bw = 4.0;
        double Cw = 3.0;
        double Dw = 1.0;
        double Fw = 0.0;

        double total = 0;
        System.out.println("Why hello there, im your new personal GPA Calculator");
        System.out.println(" ");
        ////CLASS ONE
        for (int i = 0; i < 7; i++){
            System.out.println("Is your first class weighted?");
            String classw1 = UserInput.getString();
            System.out.println("Now what is your letter grade?");
            String classg1 = UserInput.getString();

            //class 1 weight no
            if (classg1.indexOf("A") >= 0 && classw1.indexOf("no") >= 0)
            {
                total = total + Ar;
            }
            else if (classg1.indexOf("B") >= 0 && classw1.indexOf("no") >= 0)
            {
                total = total + Br;
            }
            else if (classg1.indexOf("C") >= 0 && classw1.indexOf("no") >= 0)
            {
                total = total + Cr;
            }
            else if (classg1.indexOf("D") >= 0 && classw1.indexOf("no") >= 0)
            {
                total = total + Dr;
            }
            else if (classg1.indexOf("F") >= 0 && classw1.indexOf("no") >= 0)
            {
                total = total + Fr;
            }

            //class 1 weight yes
            else if (classg1.indexOf("A") >= 0 && classw1.indexOf("yes") >= 0)
            {
                total = total + Aw;
            }
            else if (classg1.indexOf("B") >= 0 && classw1.indexOf("yes") >= 0)
            {
                total = total + Bw;
            }
            else if (classg1.indexOf("C") >= 0 && classw1.indexOf("yes") >= 0)
            {
                total = total + Cw;
            }
            else if (classg1.indexOf("D") >= 0 && classw1.indexOf("yes") >= 0)
            {
                total = total + Dw;
            }
            else if (classg1.indexOf("F") >= 0 && classw1.indexOf("yes") >= 0)
            {
                total = total + Fw;
            }
        }
        total = total / 7;
        System.out.println("Your GPA is: " + df.format(total));
        
        if (total >= 4.00)
        {
            System.out.println("Your above average!");
        }
        else if (total < 4.00 && total >= 3.00)
        {
            System.out.println("Keep working your doing great!");
        }
        else if (total < 3.00 && total >= 2.00)
        {
            System.out.println("Try a little harder!");
        }
        else if (total < 2.00 && total >= 0.00)
        {
            System.out.println("Umm.. you suck!");
        }
        
    }
}