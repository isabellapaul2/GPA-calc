import java.util.Scanner;
/**
 * Write a description of class UserInput here.
 *
 * @author (your name)
 * @version (a version number or a date)
 * 
 * Convieneience class for getting user input from a user
 */
public class UserInput
{
    public static String getString()
    {
        Scanner in = new Scanner(System.in);
        return in.next();
    }
}
